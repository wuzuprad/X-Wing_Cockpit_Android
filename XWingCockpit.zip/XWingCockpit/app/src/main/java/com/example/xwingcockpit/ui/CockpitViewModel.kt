package com.example.xwingcockpit.ui

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.xwingcockpit.input.KeyStep
import com.example.xwingcockpit.input.ShizukuInjector
import com.example.xwingcockpit.model.*

class CockpitViewModel : ViewModel() {

    var game by mutableStateOf<Game?>(null); private set
    var faction by mutableStateOf<Faction?>(null); private set
    var ship by mutableStateOf<Ship?>(null); private set
    var warheads by mutableStateOf(listOf(Warhead.NONE)); private set
    var beamEnabled by mutableStateOf(false); private set
    var slamEnabled by mutableStateOf(false); private set
    var state by mutableStateOf(ShipState()); private set

    // Selected mission (TIE / XWA only). null = No Battle / Custom Mission.
    var mission by mutableStateOf<Mission?>(null); private set
    var missionBattle by mutableStateOf<String?>(null); private set

    fun selectMission(battleName: String?, m: Mission?) { missionBattle = battleName; mission = m }

    /** Send the in-flight Goals key ('g') — used to open/close the game's goals menu. */
    fun sendGoalsKey() = testKey(android.view.KeyEvent.KEYCODE_G)

    fun selectGame(g: Game) { game = g; faction = null; ship = null; mission = null; missionBattle = null }
    fun selectFaction(f: Faction) { faction = f; ship = null }

    fun selectShip(s: Ship) {
        ship = s
        beamEnabled = false
        slamEnabled = false
        state = ShipState.default(s)
        // No keys sent on select: the game already holds its own starting config.
    }

    /** Whether a beam recharge system is present for the current craft + loadout. */
    val beamActive: Boolean get() = ship?.let { it.hasBeam || (it.beamOptional && beamEnabled) } ?: false

    /** Whether this craft can mount a SLAM drive (loadout offers the toggle). */
    val slamAvailable: Boolean get() = ship?.hasSlam == true

    /** Set the mission loadout (no keys sent). Preserved across RESET. */
    fun setLoadout(list: List<Warhead>, beam: Boolean, slam: Boolean) {
        warheads = list
        beamEnabled = beam
        slamEnabled = slam
        state = state.copy(weaponIndex = 0, fireModeByWeapon = emptyMap(), slamActive = false)
    }

    /** Toggle SLAM: sends 'n' and flips the engaged state (green glow while active). */
    fun toggleSlam() {
        val km = keyMap ?: return
        if (!slamEnabled) return
        fire(km.slam)
        state = state.copy(slamActive = !state.slamActive)
    }

    /** Weapon cycle contents: LASERS + (IONS if present) + selected warheads. */
    fun weaponOptions(): List<String> = ship?.let { weaponCycle(it, warheads) } ?: listOf("LASERS")

    /** The weapon currently selected in the W-cycle. */
    fun currentWeapon(): String {
        val opts = weaponOptions()
        return opts.getOrElse(state.weaponIndex.coerceIn(0, opts.size - 1)) { "LASERS" }
    }

    /** Fire-mode options for the currently selected weapon on this craft + game. */
    fun fireModeOptions(): List<String> {
        val s = ship ?: return listOf("SINGLE")
        val g = game ?: return listOf("SINGLE")
        return fireModesFor(currentWeapon(), s, g)
    }

    /** Label for the current weapon's remembered fire mode. */
    fun fireModeLabel(): String {
        val modes = fireModeOptions()
        val idx = (state.fireModeByWeapon[currentWeapon()] ?: 0).coerceIn(0, modes.size - 1)
        return modes[idx]
    }

    /** True if the current weapon has more than one fire mode to cycle through. */
    fun fireModeCyclable(): Boolean = fireModeOptions().size > 1

    private val keyMap: KeyMap? get() = game?.keyMap

    private fun fire(step: KeyStep, times: Int = 1) {
        if (times <= 0) return
        ShizukuInjector.send(List(times) { step })
    }

    fun setShield(target: ShieldConfig) {
        val km = keyMap ?: return
        val presses = shieldPresses(state.shield, target)
        if (presses > 0) fire(km.shieldCycle, presses)
        state = state.copy(shield = target)
    }

    /** Single toggle: one S press advances equal -> forward -> rear -> equal. */
    fun cycleShield() {
        val km = keyMap ?: return
        fire(km.shieldCycle)
        val order = SHIELD_CYCLE_ORDER
        val next = order[(order.indexOf(state.shield) + 1) % order.size]
        state = state.copy(shield = next)
    }

    fun cycleWeapon() {
        val km = keyMap ?: return
        val opts = weaponOptions()
        if (opts.size <= 1) return   // No Missiles -> W does nothing
        fire(km.weaponCycle)
        state = state.copy(weaponIndex = (state.weaponIndex + 1) % opts.size)
    }

    fun cycleFireMode() {
        val km = keyMap ?: return
        val modes = fireModeOptions()
        if (modes.size <= 1) return   // single-cannon lasers (Missile Boat) — nothing to link
        val w = currentWeapon()
        fire(km.fireMode)
        val cur = state.fireModeByWeapon[w] ?: 0
        val next = (cur + 1) % modes.size
        state = state.copy(fireModeByWeapon = state.fireModeByWeapon + (w to next))
    }

    fun cycleLaserRecharge() {
        val km = keyMap ?: return
        val hs = ship?.hasShields == true
        val engine = engineBoxes(state.laserRate, state.shieldRate, hs, beamActive, state.beamRate)
        fire(km.laserRecharge)
        state = state.copy(laserRate = pressRecharge(state.laserRate, engine))
    }

    fun cycleShieldRecharge() {
        val km = keyMap ?: return; val s = ship ?: return
        if (!s.hasShields) return
        val engine = engineBoxes(state.laserRate, state.shieldRate, true, beamActive, state.beamRate)
        fire(km.shieldRecharge)
        state = state.copy(shieldRate = pressRecharge(state.shieldRate, engine))
    }

    fun cycleBeamRecharge() {
        val km = keyMap ?: return
        if (!beamActive) return
        val hs = ship?.hasShields == true
        val engine = engineBoxes(state.laserRate, state.shieldRate, hs, beamActive, state.beamRate)
        fire(km.beamRecharge)
        state = state.copy(beamRate = pressRecharge(state.beamRate, engine))
    }

    fun transferLaserToShield() { keyMap?.let { km -> ship?.let { if (it.hasShields) fire(km.xferLaserToShield) } } }
    fun transferShieldToLaser() { keyMap?.let { km -> ship?.let { if (it.hasShields) fire(km.xferShieldToLaser) } } }

    fun setThrottle(level: ThrottleLevel) {
        val km = keyMap ?: return
        val step = when (level) {
            ThrottleLevel.FULL -> km.throttleFull
            ThrottleLevel.TWO_THIRDS -> km.throttleTwoThirds
            ThrottleLevel.ONE_THIRD -> km.throttleOneThird
            ThrottleLevel.ZERO -> km.throttleZero
            ThrottleLevel.MATCHED -> km.matchSpeed
        }
        fire(step)
        state = state.copy(throttle = level)
    }

    fun reset() {
        val s = ship ?: return
        setShield(ShieldConfig.BALANCED)     // deterministic in-game resync of shields
        setThrottle(ThrottleLevel.FULL)      // games start at full throttle
        state = ShipState.default(s)
    }

    fun testKey(keyCode: Int, modKeyCode: Int? = null) {
        ShizukuInjector.send(listOf(KeyStep(keyCode, modKeyCode)))
    }

    fun sendCommand(cmd: ShipCommand) {
        ShizukuInjector.send(listOf(cmd.key))
    }
}
