package com.example.xwingcockpit

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.xwingcockpit.input.ShizukuInjector
import com.example.xwingcockpit.model.hasMissions
import com.example.xwingcockpit.ui.*

private enum class Screen { GAME, FACTION, SHIP, MISSION, LOADOUT, COCKPIT, COMMANDS, GOALS, CONFIG, DIAGNOSTICS }

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The cockpit is a touch-only panel on the second screen. It must NEVER take
        // input focus, or it steals focus from the game on the main screen — which
        // both stops the game's controller input and misdirects our injected keys.
        // FLAG_NOT_FOCUSABLE lets the panel still receive touches (buttons work) while
        // leaving the game as the focused window, so injected keys keep reaching it.
        window.addFlags(
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        )
        ShizukuInjector.start()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val vm: CockpitViewModel = viewModel()
                var screen by remember { mutableStateOf(Screen.GAME) }

                when (screen) {
                    Screen.GAME -> GameScreen(onPick = { g ->
                        vm.selectGame(g)
                        // Skip the faction step when the game has only one side.
                        if (g.factions.size == 1) {
                            vm.selectFaction(g.factions.first())
                            screen = Screen.SHIP
                        } else screen = Screen.FACTION
                    })

                    Screen.FACTION -> FactionScreen(
                        game = vm.game!!,
                        onPick = { vm.selectFaction(it); screen = Screen.SHIP },
                        onBack = { screen = Screen.GAME },
                    )

                    Screen.SHIP -> ShipScreen(
                        game = vm.game!!,
                        faction = vm.faction!!,
                        onPick = {
                            vm.selectShip(it)
                            screen = if (hasMissions(vm.game!!.id)) Screen.MISSION else Screen.LOADOUT
                        },
                        onBack = {
                            screen = if (vm.game!!.factions.size == 1) Screen.GAME else Screen.FACTION
                        },
                    )

                    Screen.MISSION -> MissionSelectScreen(
                        game = vm.game!!,
                        faction = vm.faction!!,
                        onPick = { battleName, m -> vm.selectMission(battleName, m); screen = Screen.LOADOUT },
                        onBack = { screen = Screen.SHIP },
                    )

                    Screen.LOADOUT -> LoadoutScreen(
                        game = vm.game!!,
                        faction = vm.faction!!,
                        ship = vm.ship!!,
                        onConfirm = { w, beam, slam -> vm.setLoadout(w, beam, slam); screen = Screen.COCKPIT },
                        onBack = { screen = if (hasMissions(vm.game!!.id)) Screen.MISSION else Screen.SHIP },
                    )

                    Screen.COCKPIT -> CockpitScreen(
                        vm = vm,
                        onCommands = { screen = Screen.COMMANDS },
                        onConfig = { screen = Screen.CONFIG },
                    )

                    Screen.COMMANDS -> CommandsScreen(
                        vm = vm,
                        onClose = { screen = Screen.COCKPIT },
                        onOpenGoals = { screen = Screen.GOALS },
                    )

                    Screen.GOALS -> GoalsScreen(
                        vm = vm,
                        onClose = { vm.sendGoalsKey(); screen = Screen.COMMANDS },
                    )

                    Screen.CONFIG -> ConfigScreen(
                        vm = vm,
                        onSwitchCraft = { screen = Screen.SHIP },
                        onDiagnostics = { screen = Screen.DIAGNOSTICS },
                        onClose = { screen = Screen.COCKPIT },
                    )

                    Screen.DIAGNOSTICS -> DiagnosticScreen(
                        vm = vm,
                        onBack = { screen = if (vm.ship != null) Screen.COCKPIT else Screen.GAME },
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuInjector.stop()
    }
}
