package com.example.xwingcockpit.input

import android.content.Context
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import com.example.xwingcockpit.IUserService
import java.lang.reflect.Method

/**
 * Runs INSIDE the Shizuku (shell-privileged) process, NOT the app process.
 * The shell UID holds INJECT_EVENTS, so from here we can inject key events that
 * reach whatever window is focused — the game running in Winlator/GameNative on
 * the other screen.
 *
 * We inject via InputManager.injectInputEvent (reflection) rather than the `input`
 * binary. That lets us reproduce a real keyboard's event stream for modified keys:
 *
 *     SHIFT down  ->  letter down (Shift held)  ->  letter up  ->  SHIFT up
 *
 * `input keycombination` does NOT hold the modifier in a way Wine registers, so
 * Shift+letter game commands (wingman orders, docking, etc.) arrived as the bare
 * letter. Driving the down/up sequence ourselves fixes every Shift command at once.
 * If direct injection is ever unavailable we fall back to the `input` binary.
 */
class UserService() : IUserService.Stub() {

    @Suppress("unused")
    constructor(context: Context) : this()

    override fun destroy() { exit() }
    override fun exit() { System.exit(0) }

    override fun keyEvent(keyCode: Int) {
        if (!injectTap(keyCode, 0)) exec(arrayOf(INPUT, "keyevent", keyCode.toString()))
    }

    override fun keyCombination(modKeyCode: Int, keyCode: Int) {
        if (!injectChord(modKeyCode, keyCode))
            exec(arrayOf(INPUT, "keycombination", modKeyCode.toString(), keyCode.toString()))
    }

    /** A plain key: down then up. Returns false if injection is unavailable. */
    private fun injectTap(keyCode: Int, meta: Int): Boolean {
        val t = SystemClock.uptimeMillis()
        if (!inject(key(KeyEvent.ACTION_DOWN, keyCode, meta, t, t))) return false
        hold()
        inject(key(KeyEvent.ACTION_UP, keyCode, meta, t, SystemClock.uptimeMillis()))
        return true
    }

    /** Hold [modKeyCode] down, tap [keyCode] while it's held, then release it. */
    private fun injectChord(modKeyCode: Int, keyCode: Int): Boolean {
        val meta = metaFor(modKeyCode)
        val t = SystemClock.uptimeMillis()
        if (!inject(key(KeyEvent.ACTION_DOWN, modKeyCode, 0, t, t))) return false
        gap()
        inject(key(KeyEvent.ACTION_DOWN, keyCode, meta, t, SystemClock.uptimeMillis())); hold()
        inject(key(KeyEvent.ACTION_UP, keyCode, meta, t, SystemClock.uptimeMillis())); gap()
        inject(key(KeyEvent.ACTION_UP, modKeyCode, 0, t, SystemClock.uptimeMillis()))
        return true
    }

    private fun key(action: Int, code: Int, meta: Int, downTime: Long, eventTime: Long) =
        KeyEvent(downTime, eventTime, action, code, 0, meta,
            KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD)

    private fun metaFor(mod: Int): Int = when (mod) {
        KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT ->
            KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT ->
            KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT ->
            KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        else -> 0
    }

    private fun gap() { try { Thread.sleep(GAP_MS) } catch (_: InterruptedException) {} }
    private fun hold() { try { Thread.sleep(HOLD_MS) } catch (_: InterruptedException) {} }

    // --- InputManager.injectInputEvent via reflection (shell UID has INJECT_EVENTS) ---
    private val injector: Pair<Any, Method>? by lazy {
        try {
            val cls = Class.forName("android.hardware.input.InputManager")
            val instance = cls.getMethod("getInstance").invoke(null) ?: return@lazy null
            val m = cls.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            Pair(instance, m)
        } catch (e: Throwable) { null }
    }

    private fun inject(ev: KeyEvent): Boolean {
        val i = injector ?: return false
        return try { i.second.invoke(i.first, ev, INJECT_ASYNC); true }
        catch (e: Throwable) { false }
    }

    private fun exec(cmd: Array<String>) {
        try { Runtime.getRuntime().exec(cmd).waitFor() } catch (_: Exception) {}
    }

    companion object {
        private const val INPUT = "/system/bin/input"
        private const val INJECT_ASYNC = 0   // INJECT_INPUT_EVENT_MODE_ASYNC
        private const val GAP_MS = 12L        // transition gap between modifier/key edges
        private const val HOLD_MS = 40L       // key held down long enough for the game to poll it
    }
}
