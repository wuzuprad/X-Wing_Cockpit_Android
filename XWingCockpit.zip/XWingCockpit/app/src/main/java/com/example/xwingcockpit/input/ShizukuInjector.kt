package com.example.xwingcockpit.input

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.example.xwingcockpit.BuildConfig
import com.example.xwingcockpit.IUserService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

/**
 * Owns the Shizuku connection and forwards key presses to the remote UserService.
 *
 * Status flow: UNKNOWN -> (Shizuku app installed & running?) -> NO_BINDER
 *              -> (permission granted?) -> NO_PERMISSION
 *              -> (user service bound?) -> READY
 */
object ShizukuInjector {

    enum class Status { UNKNOWN, NO_BINDER, NO_PERMISSION, CONNECTING, READY }

    @Volatile var status: Status = Status.UNKNOWN
        private set

    // Simple callback so the UI can re-render on status changes.
    var onStatusChange: ((Status) -> Unit)? = null

    private const val REQUEST_CODE = 4211
    private val scope = CoroutineScope(Dispatchers.Default)

    private var service: IUserService? = null

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(BuildConfig.APPLICATION_ID, UserService::class.java.name)
    ).daemon(false)
        .processNameSuffix("keyinjector")
        .debuggable(BuildConfig.DEBUG)
        .version(BuildConfig.VERSION_CODE)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) {
                IUserService.Stub.asInterface(binder)
            } else null
            setStatus(if (service != null) Status.READY else Status.CONNECTING)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            setStatus(Status.CONNECTING)
        }
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, grantResult ->
        if (code == REQUEST_CODE) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) bindService()
            else setStatus(Status.NO_PERMISSION)
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { init() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        setStatus(Status.NO_BINDER)
    }

    fun start() {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        init()
    }

    fun stop() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }

    /** Kick the connection process. Safe to call repeatedly (e.g. from a Retry button). */
    fun init() {
        if (!Shizuku.pingBinder()) {
            setStatus(Status.NO_BINDER)
            return
        }
        if (Shizuku.isPreV11()) {
            // Very old Shizuku; unsupported here.
            setStatus(Status.NO_BINDER)
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            bindService()
        } else {
            setStatus(Status.NO_PERMISSION)
        }
    }

    fun requestPermission() {
        if (!Shizuku.pingBinder()) { setStatus(Status.NO_BINDER); return }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) bindService()
        else Shizuku.requestPermission(REQUEST_CODE)
    }

    private fun bindService() {
        setStatus(Status.CONNECTING)
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (e: Exception) {
            setStatus(Status.CONNECTING)
        }
    }

    val isReady: Boolean get() = status == Status.READY && service != null

    /**
     * Sends a list of key steps in order, with a small delay between them so the
     * game reliably registers discrete presses (important for multi-press cycles).
     */
    fun send(steps: List<KeyStep>, gapMs: Long = 60L) {
        val svc = service ?: return
        scope.launch {
            for (step in steps) {
                try {
                    if (step.modKeyCode != null) svc.keyCombination(step.modKeyCode, step.keyCode)
                    else svc.keyEvent(step.keyCode)
                } catch (_: Exception) { /* ignore transient RPC failures */ }
                delay(gapMs)
            }
        }
    }

    private fun setStatus(s: Status) {
        status = s
        onStatusChange?.invoke(s)
    }
}

/** One key action. If [modKeyCode] is set, it is held while [keyCode] is tapped. */
data class KeyStep(val keyCode: Int, val modKeyCode: Int? = null)
