package com.example.xwingcockpit.model

import android.view.KeyEvent
import com.example.xwingcockpit.input.KeyStep

/* ----------------------------------------------------------------------------
 * DATA-DRIVEN CONFIG  — edit this file only to add games / ships / rebind keys.
 * The UI and injector never change.
 *
 * Selection flow: GAME -> FACTION (filtered by game) -> SHIP (filtered by
 * game + faction). Artwork is shared per ship TYPE across all games (one
 * X-Wing cockpit, reused everywhere it appears).
 *
 * Keys verified against series manuals / Emperor's Hammer keyboard reference:
 *   S  cycle shields (forward / rear / equal)   W  cycle weapons
 *   X  cycle firing mode                        B  toggle beam weapon
 *   F9 laser recharge   F10 shield recharge      F8 beam recharge
 *   Energy transfer: ' laser->shields, ; shields->lasers (single-key; avoids Shift chords).
 *   These are layout-independent through Winlator. The ' and ; keys do the same
 *   thing and are the fallback if the Shift combos don't register (test both in
 *   Diagnostics, then set whichever works here).
 * ------------------------------------------------------------------------- */

enum class Faction(val display: String) { REBEL("Rebel Alliance"), IMPERIAL("Galactic Empire") }

enum class GameId(val display: String, val shortName: String) {
    XWING("Star Wars: X-Wing", "X-WING"),
    TIE("Star Wars: TIE Fighter", "TIE FIGHTER"),
    XVT("X-Wing vs TIE Fighter", "XvT"),
    XWA("X-Wing Alliance", "XWA"),
}

enum class ShieldConfig(val label: String) { BALANCED("EQUAL"), FORWARD("FWD"), REAR("REAR") }

/** In-game order the S key cycles (verified on hardware): balanced, then rear, then forward. */
val SHIELD_CYCLE_ORDER = listOf(ShieldConfig.BALANCED, ShieldConfig.REAR, ShieldConfig.FORWARD)

/* ------------------------------ FIRE MODES -------------------------------
 * Fire mode ("linking") is per-weapon and depends on the craft:
 *   Lasers:  1 cannon -> SINGLE only;  2 -> SINGLE/DUAL;  4 -> SINGLE/DUAL/QUAD.
 *            In XWA ONLY, craft carrying ion cannons append a combined LAS+ION
 *            link as the final laser state (e.g. XWA Defender: S/D/QUAD/LAS+ION).
 *   Ions / warheads: always SINGLE/DUAL. Warheads never link with lasers/ions.
 * ------------------------------------------------------------------------- */
fun laserFireModes(ship: Ship, game: Game): List<String> {
    val base = when {
        ship.laserCannons >= 4 -> listOf("SINGLE", "DUAL", "QUAD")
        ship.laserCannons == 3 -> listOf("SINGLE", "TRIPLE")   // B-Wing: 3 lasers, no dual mode
        ship.laserCannons == 2 -> listOf("SINGLE", "DUAL")
        else -> listOf("SINGLE")            // single cannon (Missile Boat) — no laser link
    }
    return if (game.id == GameId.XWA && ship.hasIonCannons) base + "LAS+ION" else base
}

fun fireModesFor(weapon: String, ship: Ship, game: Game): List<String> = when (weapon) {
    "LASERS" -> laserFireModes(ship, game)
    else -> listOf("SINGLE", "DUAL")        // ion cannons and warheads
}

/* --------------------------- ENERGY / RECHARGE ----------------------------
 * Laser / Shield / Beam each have 4 boxes = 5 states (0..4), default 2. F-key
 * press advances one box and wraps 4->0. Engine is DERIVED and display-only.
 *
 * The beam SYSTEM adds capacity: pool is 8 without beam, 10 with beam. Beam
 * recharge draws from that pool like laser/shield, so:
 *   engine = pool - laser - shield - beam      (beam term only when beam is on)
 * Net effect: with beam on and beam charge low, you have +2 headroom for engine
 * or the other systems; charging the beam spends it back.
 * ------------------------------------------------------------------------- */
const val RATE_STATES = 5            // 0..4 filled boxes
const val ENGINE_POOL_SHIELDED = 8
const val ENGINE_POOL_UNSHIELDED = 6 // shieldless craft (TIE Fighter/Interceptor/Bomber) have a smaller reactor
const val BEAM_BONUS = 2
fun enginePool(hasShields: Boolean, beamActive: Boolean) =
    (if (hasShields) ENGINE_POOL_SHIELDED else ENGINE_POOL_UNSHIELDED) + (if (beamActive) BEAM_BONUS else 0)
fun engineBoxes(laserRate: Int, shieldRate: Int, hasShields: Boolean, beamActive: Boolean, beamRate: Int): Int {
    val pool = enginePool(hasShields, beamActive)
    // Shieldless craft reserve the top engine box (never fully lit): with laser 2 the
    // engine sits at 3 (level with laser), climbs to 5 at laser 0, drops to 1 at laser 4.
    val reserve = if (hasShields) 0 else 1
    val draw = laserRate + (if (hasShields) shieldRate else 0) + (if (beamActive) beamRate else 0)
    return (pool - reserve - draw).coerceIn(0, pool)
}

/**
 * New rate after ONE recharge keypress, honoring energy conservation:
 *  - at max -> wrap to 0 (returns all its boxes to the engine)
 *  - else if the engine has a box to give -> +1 (draws one from the engine)
 *  - else (engine empty, can't draw) -> dump to 0, returning its boxes to engine
 */
fun pressRecharge(current: Int, engineAvailable: Int): Int = when {
    current >= RATE_STATES - 1 -> 0
    engineAvailable > 0 -> current + 1
    else -> 0
}

// Fixed presets participate in the "currently selected" glow. MATCHED is set by
// Match-Speed (Enter): the resulting speed is unknown to the app, so it's tracked
// as its own state rather than a fixed level.
enum class ThrottleLevel { FULL, TWO_THIRDS, ONE_THIRD, ZERO, MATCHED }

/* ------------------------------- WARHEADS --------------------------------- */
// Mission loadout. NONE means no warheads. Selecting a loadout sends NO keys —
// it only tells the app what the W weapon-cycle should contain.
enum class Warhead(val display: String) {
    NONE("No Missiles"),
    MISSILES("Missiles"),
    ADV_MISSILES("Adv Missiles"),
    TORPEDOES("Torpedoes"),
    ADV_TORPEDOES("Adv Torpedoes"),
    HEAVY_ROCKET("Heavy Rocket"),
    SPACE_BOMB("Space Bomb"),
    MAG_PULSE("Mag Pulse"),
}

// Original X-Wing had only concussion missiles + proton torpedoes.
val XWING_WARHEADS = listOf(Warhead.NONE, Warhead.MISSILES, Warhead.TORPEDOES)
// TIE Fighter through XWA had the full menu.
val FULL_WARHEADS = Warhead.values().toList()

/** Weapon cycle in the cockpit = LASERS + the distinct selected warhead types. */
// W cycles: Lasers -> (Ions, if the craft has them) -> each distinct loaded warhead.
fun weaponCycle(ship: Ship, warheads: List<Warhead>): List<String> {
    val missiles = warheads.filter { it != Warhead.NONE }.distinct().map { it.display.uppercase() }
    val list = mutableListOf("LASERS")
    if (ship.hasIonCannons) list.add("IONS")
    list.addAll(missiles)
    return list
}

/* -------------------------- SHIP / WINGMAN COMMANDS -----------------------
 * Comms & docking orders shown in the COMMANDS overlay. Wingman orders (Shift+
 * letter) are shared across the series; docking/rearm are XvT/XWA. NOTE: Shift+R
 * is "report in" in the classic games but "release object" in XWA — verify.
 * ------------------------------------------------------------------------- */
data class ShipCommand(val label: String, val key: KeyStep)
data class CommandGroup(val title: String, val commands: List<ShipCommand>)

private fun shift(code: Int) = KeyStep(code, KeyEvent.KEYCODE_SHIFT_LEFT)

val COMMAND_GROUPS = listOf(
    CommandGroup("SHIP", listOf(
        ShipCommand("NEXT TARGET", KeyStep(KeyEvent.KEYCODE_T)),
        ShipCommand("PREV TARGET", KeyStep(KeyEvent.KEYCODE_Y)),
        ShipCommand("NEAREST FIGHTER", KeyStep(KeyEvent.KEYCODE_R)),
        ShipCommand("ENTER HANGAR", KeyStep(KeyEvent.KEYCODE_SPACE)),
        ShipCommand("ENGAGE HYPERDRIVE", KeyStep(KeyEvent.KEYCODE_H)),
        ShipCommand("COCKPIT DISPLAY", KeyStep(KeyEvent.KEYCODE_I)),
    )),
    CommandGroup("WINGMAN ORDERS", listOf(
        ShipCommand("ATTACK TARGET", shift(KeyEvent.KEYCODE_A)),
        ShipCommand("IGNORE TARGET", shift(KeyEvent.KEYCODE_I)),
        ShipCommand("EVADE", shift(KeyEvent.KEYCODE_E)),
        ShipCommand("WAIT / HOLD", shift(KeyEvent.KEYCODE_W)),
        ShipCommand("GO / PROCEED", shift(KeyEvent.KEYCODE_G)),
        ShipCommand("HYPER HOME", shift(KeyEvent.KEYCODE_H)),
        ShipCommand("REPORT IN", shift(KeyEvent.KEYCODE_R)),
    )),
    CommandGroup("DOCKING / CARGO", listOf(
        ShipCommand("DOCK TARGET", shift(KeyEvent.KEYCODE_D)),
        ShipCommand("REARM ME", shift(KeyEvent.KEYCODE_B)),
        ShipCommand("PICK UP OBJ", shift(KeyEvent.KEYCODE_P)),
    )),
    CommandGroup("DISPLAYS", listOf(
        ShipCommand("MISSION GOALS", KeyStep(KeyEvent.KEYCODE_G)),
        ShipCommand("MESSAGE LOG", KeyStep(KeyEvent.KEYCODE_L)),
        ShipCommand("DAMAGE", KeyStep(KeyEvent.KEYCODE_D)),
        ShipCommand("IN-FLIGHT MAP", KeyStep(KeyEvent.KEYCODE_M)),
        ShipCommand("TARGET THREAT", KeyStep(KeyEvent.KEYCODE_Z)),
        ShipCommand("KEYBOARD REF", KeyStep(KeyEvent.KEYCODE_K)),
    )),
)

/* ------------------------------- KEY MAPS --------------------------------- */

data class KeyMap(
    val shieldCycle: KeyStep = KeyStep(KeyEvent.KEYCODE_S),
    val weaponCycle: KeyStep = KeyStep(KeyEvent.KEYCODE_W),
    val fireMode: KeyStep = KeyStep(KeyEvent.KEYCODE_X),
    val laserRecharge: KeyStep = KeyStep(KeyEvent.KEYCODE_F9),
    val shieldRecharge: KeyStep = KeyStep(KeyEvent.KEYCODE_F10),
    val beamRecharge: KeyStep = KeyStep(KeyEvent.KEYCODE_F8),
    // Single-key energy transfer — reliable through Winlator/Wine, unlike the Shift+F9/F10
    // chords, which drop the Shift modifier so the game only sees the bare function key.
    //   ' (apostrophe) = laser -> shields      ; (semicolon) = shields -> lasers
    val xferLaserToShield: KeyStep = KeyStep(KeyEvent.KEYCODE_APOSTROPHE),
    val xferShieldToLaser: KeyStep = KeyStep(KeyEvent.KEYCODE_SEMICOLON),
    val beamToggle: KeyStep = KeyStep(KeyEvent.KEYCODE_B),
    val slam: KeyStep = KeyStep(KeyEvent.KEYCODE_N),   // SLAM: dump laser energy into engines
    // Throttle. Backspace/Enter are stable; the bracket/backslash/slash keys are
    // punctuation and may be layout-sensitive through Winlator (test in-game).
    val throttleFull: KeyStep = KeyStep(KeyEvent.KEYCODE_DEL),          // Backspace
    val throttleTwoThirds: KeyStep = KeyStep(KeyEvent.KEYCODE_RIGHT_BRACKET), // ]
    val throttleOneThird: KeyStep = KeyStep(KeyEvent.KEYCODE_LEFT_BRACKET),   // [
    val throttleZero: KeyStep = KeyStep(KeyEvent.KEYCODE_BACKSLASH),   // \  (XWA overrides to /)
    val matchSpeed: KeyStep = KeyStep(KeyEvent.KEYCODE_ENTER),
)

// Shared classic scheme. Each game references its own so it can diverge later
// with e.g.  val TIE_KEYMAP = CLASSIC_KEYMAP.copy(fireMode = KeyStep(...))
val CLASSIC_KEYMAP = KeyMap()
val XWING_KEYMAP = CLASSIC_KEYMAP
val TIE_KEYMAP = CLASSIC_KEYMAP
val XVT_KEYMAP = CLASSIC_KEYMAP
// XWA uses / (full stop) for zero throttle instead of the older games' \ .
val XWA_KEYMAP = CLASSIC_KEYMAP.copy(throttleZero = KeyStep(KeyEvent.KEYCODE_SLASH))

/* -------------------------------- GAMES ----------------------------------- */

data class Game(
    val id: GameId,
    val factions: List<Faction>,
    val keyMap: KeyMap,
    val warheads: List<Warhead>,
)

val GAMES = listOf(
    Game(GameId.XWING, listOf(Faction.REBEL), XWING_KEYMAP, XWING_WARHEADS),
    Game(GameId.TIE, listOf(Faction.IMPERIAL), TIE_KEYMAP, FULL_WARHEADS),
    Game(GameId.XVT, listOf(Faction.REBEL, Faction.IMPERIAL), XVT_KEYMAP, FULL_WARHEADS),
    Game(GameId.XWA, listOf(Faction.REBEL, Faction.IMPERIAL), XWA_KEYMAP, FULL_WARHEADS),
)

/* -------------------------------- SHIPS ----------------------------------- */

data class Ship(
    val id: String,
    val name: String,
    val faction: Faction,
    val art: String,                 // shared drawable id per ship TYPE (placeholder for now)
    val games: Set<GameId>,          // which games this craft is flyable in
    val hasShields: Boolean,
    val hasBeam: Boolean,            // beam always present (e.g. Gunboat)
    val beamOptional: Boolean = false, // beam chosen on the loadout screen (Defender, Missile Boat)
    val warheadSlots: Int = 1,       // craft that can load two warhead types (Missile Boat) = 2
    val laserCannons: Int = 2,       // 1 -> SINGLE only; 2 -> SINGLE/DUAL; 4 -> SINGLE/DUAL/QUAD
    val hasIonCannons: Boolean = false, // adds IONS as a selectable weapon; enables LAS+ION link in XWA
    val hasSlam: Boolean = false,    // SLAM drive available as a loadout option ('n' key)
)

// Roster = sensible starting defaults. Easily edited; not guaranteed exhaustive.
val SHIPS: List<Ship> = listOf(
    // --- Rebel ---
    Ship("xwing", "X-Wing", Faction.REBEL, "cockpit_xwing",
        setOf(GameId.XWING, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 4),
    Ship("ywing", "Y-Wing", Faction.REBEL, "cockpit_ywing",
        setOf(GameId.XWING, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 2, hasIonCannons = true),
    Ship("awing", "A-Wing", Faction.REBEL, "cockpit_awing",
        setOf(GameId.XWING, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 2),
    Ship("bwing", "B-Wing", Faction.REBEL, "cockpit_bwing",
        setOf(GameId.XWING, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 3, hasIonCannons = true),   // 3 lasers + 2 ion: SINGLE/TRIPLE (+LAS+ION in XWA)
    Ship("z95", "Z-95 Headhunter", Faction.REBEL, "cockpit_z95",
        setOf(GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 2),                          // XWA only; like an X-Wing but 2 lasers

    // --- Imperial ---
    Ship("tie_fighter", "TIE Fighter", Faction.IMPERIAL, "cockpit_tie",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = false, hasBeam = false),
    Ship("tie_interceptor", "TIE Interceptor", Faction.IMPERIAL, "cockpit_tie_interceptor",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = false, hasBeam = false,
        laserCannons = 4),
    Ship("tie_bomber", "TIE Bomber", Faction.IMPERIAL, "cockpit_tie_bomber",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = false, hasBeam = false),
    Ship("tie_advanced", "TIE Advanced", Faction.IMPERIAL, "cockpit_tie_adv",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 4),
    Ship("gunboat", "Assault Gunboat", Faction.IMPERIAL, "cockpit_gunboat",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false,
        laserCannons = 2, hasIonCannons = true, hasSlam = true),
    Ship("tie_defender", "TIE Defender", Faction.IMPERIAL, "cockpit_tie_defender",
        setOf(GameId.TIE, GameId.XVT, GameId.XWA), hasShields = true, hasBeam = false, beamOptional = true,
        laserCannons = 4, hasIonCannons = true, hasSlam = true),
    Ship("missile_boat", "Missile Boat", Faction.IMPERIAL, "cockpit_missileboat",
        setOf(GameId.TIE, GameId.XWA), hasShields = true, hasBeam = false, beamOptional = true, warheadSlots = 2,
        laserCannons = 1, hasSlam = true),
)

fun factionsFor(game: Game) = game.factions
fun shipsFor(game: Game, faction: Faction) =
    SHIPS.filter { game.id in it.games && it.faction == faction }

/* ----------------------------- LIVE STATE --------------------------------- */

data class ShipState(
    val shield: ShieldConfig = ShieldConfig.BALANCED,
    val weaponIndex: Int = 0,
    val fireModeByWeapon: Map<String, Int> = emptyMap(),  // each weapon remembers its own link state
    val throttle: ThrottleLevel = ThrottleLevel.FULL,  // games start at full throttle
    val laserRate: Int = 2,    // 0..4 filled boxes
    val shieldRate: Int = 2,   // 0..4 filled boxes (0 for shieldless craft)
    val beamRate: Int = 2,     // 0..4 filled boxes
    val slamActive: Boolean = false,   // SLAM engaged (toggle)
) {
    companion object {
        fun default(ship: Ship) = ShipState(
            laserRate = 2,
            shieldRate = if (ship.hasShields) 2 else 0,
            beamRate = 2,
        )
    }
}

fun shieldPresses(from: ShieldConfig, to: ShieldConfig): Int {
    val a = SHIELD_CYCLE_ORDER.indexOf(from)
    val b = SHIELD_CYCLE_ORDER.indexOf(to)
    if (a < 0 || b < 0) return 0
    val n = SHIELD_CYCLE_ORDER.size
    return ((b - a) % n + n) % n
}
