package com.example.xwingcockpit.model

import android.content.Context
import org.json.JSONObject

/* ------------------------------------------------------------------------
 * Mission / bonus-goal data. Loaded from assets/missions.json (generated
 * from the TIE Fighter + X-Wing Alliance goal docs). Only TIE and XWA carry
 * data today; other games return an empty list and skip mission selection.
 * ---------------------------------------------------------------------- */

data class MissionGoal(val h: Boolean, val m: Boolean, val e: Boolean, val text: String)

data class Mission(
    val name: String,
    val desc: String = "",                 // TIE: mission briefing line
    val group: String = "",                // optional sub-heading within a battle/tour (e.g. craft)
    val goals: List<MissionGoal> = emptyList(), // TIE: bonus goals w/ difficulty flags
    val craft: String = "",                // XWA
    val objectives: List<String> = emptyList(), // XWA: primary goals
    val bonus: List<String> = emptyList(), // XWA: secret bonus goals (point values)
    val opponents: List<String> = emptyList(),
    val difficulties: List<String> = emptyList(),
    val tips: List<String> = emptyList(),
    val souvenir: String = "",
)

data class Battle(val name: String, val missions: List<Mission>)

/** Which games have mission data (and therefore a mission-select step). */
fun hasMissions(gameId: GameId): Boolean =
    gameId == GameId.TIE || gameId == GameId.XWA || gameId == GameId.XWING

object MissionRepository {
    private val cache = HashMap<String, List<Battle>>()

    fun battles(context: Context, gameId: GameId): List<Battle> {
        val key = gameId.name
        cache[key]?.let { return it }
        val parsed = try {
            val text = context.assets.open("missions.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            if (!root.has(key)) emptyList() else {
                val arr = root.getJSONArray(key)
                (0 until arr.length()).map { bi ->
                    val bo = arr.getJSONObject(bi)
                    val ms = bo.getJSONArray("missions")
                    Battle(
                        name = bo.optString("name"),
                        missions = (0 until ms.length()).map { mi -> parseMission(ms.getJSONObject(mi)) }
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
        cache[key] = parsed
        return parsed
    }

    private fun parseMission(o: JSONObject): Mission {
        fun strList(field: String): List<String> {
            val a = o.optJSONArray(field) ?: return emptyList()
            return (0 until a.length()).map { a.getString(it) }
        }
        val goalsArr = o.optJSONArray("goals")
        val goals = if (goalsArr == null) emptyList() else
            (0 until goalsArr.length()).map {
                val g = goalsArr.getJSONObject(it)
                MissionGoal(g.optBoolean("h"), g.optBoolean("m"), g.optBoolean("e"), g.optString("text"))
            }
        return Mission(
            name = o.optString("name"),
            desc = o.optString("desc"),
            group = o.optString("group"),
            goals = goals,
            craft = o.optString("craft"),
            objectives = strList("objectives"),
            bonus = strList("bonus"),
            opponents = strList("opponents"),
            difficulties = strList("difficulties"),
            tips = strList("tips"),
            souvenir = o.optString("souvenir"),
        )
    }
}
