package com.example.xwingcockpit;

interface IUserService {
    // Reserved id used by the Shizuku server to tear down the service.
    void destroy() = 16777114;
    // Our own graceful exit.
    void exit() = 1;
    // Send a single Android keycode as a key press (down + up).
    void keyEvent(int keyCode) = 2;
    // Hold a modifier keycode while pressing another key (Android 12+ "input keycombination").
    void keyCombination(int modKeyCode, int keyCode) = 3;
}
