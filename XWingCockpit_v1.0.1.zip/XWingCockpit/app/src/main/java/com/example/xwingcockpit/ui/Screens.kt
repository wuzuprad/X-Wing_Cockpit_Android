package com.example.xwingcockpit.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.xwingcockpit.input.ShizukuInjector
import com.example.xwingcockpit.model.*

/* palette */
val Bg = Color(0xFF05070C)
val Panel = Color(0xFF0E1524)
val Cyan = Color(0xFF37E0FF)
val Green = Color(0xFF49F06B)
val Amber = Color(0xFFFFB020)
val Red = Color(0xFFFF4D4D)
val Dim = Color(0xFF5A6B85)
val GlowGreen = Color(0xFF5CFF7A)   // selected throttle
val DarkRed = Color(0xFF3A1212)     // unselected throttle bg
val DarkRedText = Color(0xFFC85A5A)
val ShieldYellow = Color(0xFFEEE04A) // shield recharge column
val EngineBlue = Color(0xFF8FD3E8)   // engine recharge column
val BeamPurple = Color(0xFFB05CD0)   // beam recharge column

private fun accentFor(f: Faction?) = if (f == Faction.IMPERIAL) Amber else Cyan

@Composable
fun HudScaffold(content: @Composable ColumnScope.() -> Unit) {
    Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(12.dp), content = content)
    }
}

@Composable
fun HudLabel(text: String, color: Color = Dim, size: Int = 12) =
    Text(text, color = color, fontSize = size.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)

/** Touch-only tap. Deliberately NOT keyboard/DPAD focusable, so injected key
 *  events (Enter, Space, etc.) meant for the game can never trigger the app's
 *  own HUD controls when the app happens to hold window focus. */
@Composable
private fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier {
    if (!enabled) return this
    val cb by rememberUpdatedState(onClick)
    return this.pointerInput(Unit) { detectTapGestures(onPress = { cb(); tryAwaitRelease() }) }
}

@Composable
fun HudButton(label: String, active: Boolean = false, accent: Color = Cyan,
              inactiveColor: Color = Color(0xFFB9C6DA), fontSize: Int = 14, singleLine: Boolean = false,
              modifier: Modifier = Modifier, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onClick)
    val bg = when { pressed -> GlowGreen.copy(alpha = 0.32f); active -> accent.copy(alpha = 0.22f); else -> Panel }
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(bg)
            .pointerInput(Unit) {
                detectTapGestures(
                    // Flash on press, but ACTIVATE on tap-release so the menu/command
                    // lists stay scrollable: a press-drag scrolls instead of triggering
                    // the button. (Fixed cockpit controls fire on press-down instead,
                    // for gameplay immediacy — they're never inside a scroll area.)
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { cb() })
            }
            .padding(vertical = 14.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (active) accent else inactiveColor,
            fontSize = fontSize.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            maxLines = if (singleLine) 1 else Int.MAX_VALUE, softWrap = !singleLine)
    }
}

/** Weapon toggle rendered as a filled button color-coded by weapon type:
 *  lasers = green, ions = blue, warheads = red — so it's obvious it's a control. */
@Composable
private fun WeaponButton(label: String, enabled: Boolean = true,
                         modifier: Modifier = Modifier, onClick: () -> Unit) {
    val color = when {
        label.startsWith("LASER") -> Green
        label.startsWith("ION") -> CannonRing
        else -> Red
    }
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onClick)
    val bg = if (pressed) color.copy(alpha = 0.55f) else color.copy(alpha = 0.26f)
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(bg)
            .border(1.5.dp, color.copy(alpha = 0.85f), RoundedCornerShape(6.dp))
            .then(if (enabled) Modifier.pointerInput(Unit) {
                detectTapGestures(onPress = { pressed = true; cb(); tryAwaitRelease(); pressed = false })
            } else Modifier)
            .padding(vertical = 14.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/** Energy-transfer button: each system word in its own colour, red arrow, brightens while held. */
@Composable
private fun TransferButton(w1: String, c1: Color, w2: String, c2: Color, bg: Color,
                           modifier: Modifier, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onClick)
    val text = buildAnnotatedString {
        withStyle(SpanStyle(color = c1)) { append(w1) }
        withStyle(SpanStyle(color = Red)) { append("  →  ") }
        withStyle(SpanStyle(color = c2)) { append(w2) }
    }
    Box(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (pressed) bg.copy(alpha = 0.55f) else bg.copy(alpha = 0.20f))
            .pointerInput(Unit) {
                detectTapGestures(
                    // Fire on touch-DOWN so a quick/light press can't flash without sending.
                    onPress = { pressed = true; cb(); tryAwaitRelease(); pressed = false })
            }
            .padding(vertical = 14.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
            maxLines = 1, softWrap = false)
    }
}

/** SLAM toggle under the throttle: grey when not equipped, dark-red idle, green glow when engaged. */
@Composable
private fun SlamButton(enabled: Boolean, active: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg = when { !enabled -> Panel; active -> GlowGreen.copy(alpha = 0.28f); else -> DarkRed }
    val fg = when { !enabled -> Dim; active -> GlowGreen; else -> DarkRedText }
    Box(
        modifier.clip(RoundedCornerShape(6.dp)).background(bg)
            .then(if (enabled && active) Modifier.border(2.dp, GlowGreen, RoundedCornerShape(6.dp)) else Modifier)
            .tap(enabled) { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text("SLAM", color = fg, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

/* ------------------------------- GAME ------------------------------------- */
@Composable
fun GameScreen(onPick: (Game) -> Unit) {
    HudScaffold {
        HudLabel("SELECT GAME", Cyan, 18)
        Spacer(Modifier.height(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            GAMES.forEach { g ->
                HudButton(g.id.display, modifier = Modifier.fillMaxWidth()) { onPick(g) }
            }
        }
    }
}

/* ------------------------------ FACTION ----------------------------------- */
@Composable
fun FactionScreen(game: Game, onPick: (Faction) -> Unit, onBack: () -> Unit) {
    HudScaffold {
        HudLabel(game.id.shortName + "  ·  SELECT ALLEGIANCE", Cyan, 16)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            game.factions.forEach { f ->
                FactionButton(f, Modifier.weight(1f)) { onPick(f) }
            }
        }
        Spacer(Modifier.weight(1f))
        HudButton("BACK", accent = Dim, modifier = Modifier.fillMaxWidth()) { onBack() }
    }
}

@Composable
private fun FactionButton(faction: Faction, modifier: Modifier, onClick: () -> Unit) {
    // Rebel = shields-selected green; Empire = unselected-throttle dark red.
    val (bg, fg) = when (faction) {
        Faction.REBEL -> Green.copy(alpha = 0.22f) to Green
        Faction.IMPERIAL -> DarkRed to DarkRedText
    }
    var pressed by remember { mutableStateOf(false) }
    val cb by rememberUpdatedState(onClick)
    Box(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (pressed) GlowGreen.copy(alpha = 0.32f) else bg)
            .pointerInput(Unit) {
                detectTapGestures(
                    // Fire on touch-DOWN so a quick/light press can't flash without sending.
                    onPress = { pressed = true; cb(); tryAwaitRelease(); pressed = false })
            }
            .padding(vertical = 14.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(faction.display, color = fg, fontSize = 14.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

/* -------------------------------- SHIP ------------------------------------ */
@Composable
fun ShipScreen(game: Game, faction: Faction, onPick: (Ship) -> Unit, onBack: () -> Unit) {
    val accent = accentFor(faction)
    HudScaffold {
        HudLabel("${game.id.shortName}  ·  ${faction.display.uppercase()}  ·  SELECT CRAFT", accent, 15)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            shipsFor(game, faction).forEach { ship ->
                HudButton(ship.name, accent = accent, modifier = Modifier.fillMaxWidth()) { onPick(ship) }
            }
        }
        Spacer(Modifier.height(8.dp))
        HudButton("BACK", accent = Dim, modifier = Modifier.fillMaxWidth()) { onBack() }
    }
}

/* ------------------------------ LOADOUT ----------------------------------- */
@Composable
fun LoadoutScreen(game: Game, faction: Faction, ship: Ship,
                  onConfirm: (List<Warhead>, Boolean, Boolean) -> Unit, onBack: () -> Unit) {
    val accent = accentFor(faction)
    val default = game.warheads.firstOrNull { it != Warhead.NONE } ?: Warhead.NONE
    val slots = remember(ship.id) {
        mutableStateListOf<Warhead>().apply { repeat(ship.warheadSlots) { add(default) } }
    }
    var beamOn by remember(ship.id) { mutableStateOf(false) } // beam is a later-game tech; default off
    var slamOn by remember(ship.id) { mutableStateOf(false) }
    HudScaffold {
        HudLabel("${game.id.shortName}  ·  ${ship.name.uppercase()}  ·  LOADOUT", accent, 15)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            for (slot in 0 until ship.warheadSlots) {
                val title = when {
                    ship.warheadSlots == 1 -> "WARHEAD"
                    slot == 0 -> "PRIMARY WARHEAD"
                    else -> "SECONDARY WARHEAD"
                }
                HudLabel(title, accent, 13)
                game.warheads.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { w ->
                            HudButton(w.display, active = slots[slot] == w, accent = Amber,
                                modifier = Modifier.weight(1f)) { slots[slot] = w }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            if (ship.beamOptional) {
                HudLabel("BEAM WEAPON", accent, 13)
                HudButton(if (beamOn) "BEAM: ON" else "BEAM: OFF",
                    active = beamOn, accent = BeamPurple, inactiveColor = Color(0xFF4E6E86),
                    modifier = Modifier.fillMaxWidth()) { beamOn = !beamOn }
            }
            if (ship.hasSlam) {
                HudLabel("SLAM DRIVE", accent, 13)
                HudButton(if (slamOn) "SLAM: ON" else "SLAM: OFF",
                    active = slamOn, accent = GlowGreen, inactiveColor = Color(0xFF4E6E86),
                    modifier = Modifier.fillMaxWidth()) { slamOn = !slamOn }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("BACK", accent = Dim, modifier = Modifier.weight(1f)) { onBack() }
            HudButton("CONFIRM LOADOUT", accent = Green, modifier = Modifier.weight(2f)) { onConfirm(slots.toList(), beamOn, slamOn) }
        }
    }
}

/* ------------------------------ COCKPIT ----------------------------------- */
@Composable
fun CockpitScreen(vm: CockpitViewModel, onCommands: () -> Unit, onConfig: () -> Unit) {
    val ship = vm.ship ?: return
    val game = vm.game ?: return
    val st = vm.state
    val accent = accentFor(ship.faction)
    val laserColor = if (ship.faction == Faction.REBEL) Red else Green
    val beam = vm.beamActive
    val rechargeCols = 2 + (if (ship.hasShields) 1 else 0) + (if (beam) 1 else 0)
    val leftW = maxOf(rechargeCols * 46, 172).dp

    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel(ship.name.uppercase(), accent, 18)
            Spacer(Modifier.width(8.dp))
            HudLabel(game.id.shortName, Dim, 11)
            Spacer(Modifier.weight(1f))
            val ready = ShizukuInjector.isReady
            HudLabel(if (ready) "LINK ●" else "NO LINK ○", if (ready) Green else Red, 12)
        }
        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {

            // LEFT: recharge columns, with Commands / Config tucked underneath
            Column(Modifier.width(leftW).fillMaxHeight()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                    RechargeColumns(st, ship.hasShields, beam, laserColor, vm,
                        Modifier.width((rechargeCols * 46).dp).fillMaxHeight())
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HudButton("COMMANDS", accent = Amber, fontSize = 11, singleLine = true,
                        modifier = Modifier.weight(1f)) { onCommands() }
                    HudButton("CONFIG", accent = Dim, fontSize = 11, singleLine = true,
                        modifier = Modifier.weight(1f)) { onConfig() }
                }
            }

            // MIDDLE: top-down stack — ship/shield, weapon, fire mode, energy transfer
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(10.dp))
                .background(Panel).padding(horizontal = 12.dp, vertical = 10.dp)) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    // 1. Ship silhouette + shield control
                    Box(Modifier.fillMaxWidth().weight(1.1f), contentAlignment = Alignment.Center) {
                        ShipIndicator(ship.art, ship.hasShields, st.shield, { vm.cycleShield() },
                            Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.height(8.dp))
                    // 2. Weapon selection
                    HudLabel("WEAPON", accent, 12)
                    Spacer(Modifier.height(4.dp))
                    val opts = vm.weaponOptions()
                    if (opts.size <= 1) {
                        WeaponButton("LASERS ONLY", enabled = false,
                            modifier = Modifier.fillMaxWidth()) { }
                    } else {
                        val idx = st.weaponIndex.coerceIn(0, opts.size - 1)
                        WeaponButton(opts[idx], modifier = Modifier.fillMaxWidth()) { vm.cycleWeapon() }
                    }
                    Spacer(Modifier.height(10.dp))
                    // 3. Fire mode (kept square so the cannon pattern stays proportional)
                    HudLabel("FIRE MODE", accent, 12)
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().weight(0.85f), contentAlignment = Alignment.Center) {
                        val cyclable = vm.fireModeCyclable()
                        FireModeGraphic(ship, vm.currentWeapon(), vm.fireModeLabel(),
                            Modifier.fillMaxHeight().aspectRatio(1f).tap(cyclable) { vm.cycleFireMode() })
                    }
                    // 4. Energy transfer
                    if (ship.hasShields) {
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TransferButton("S", ShieldYellow, "L", Green, Green, Modifier.weight(1f)) { vm.transferShieldToLaser() }
                            TransferButton("L", Green, "S", ShieldYellow, ShieldYellow, Modifier.weight(1f)) { vm.transferLaserToShield() }
                        }
                    }
                }
            }

            // RIGHT: throttle, with SLAM tucked underneath (only on SLAM-capable craft)
            Column(Modifier.width(100.dp).fillMaxHeight()) {
                ThrottleColumn(st.throttle, { vm.setThrottle(it) }, Modifier.weight(1f).fillMaxWidth())
                if (vm.slamAvailable) {
                    Spacer(Modifier.height(6.dp))
                    SlamButton(vm.slamEnabled, st.slamActive, Modifier.fillMaxWidth()) { vm.toggleSlam() }
                }
            }
        }
    }
}

/* --------------------------- RECHARGE COLUMNS ----------------------------- */
@Composable
private fun RechargeColumns(st: ShipState, hasShields: Boolean, beam: Boolean, laserColor: Color,
                            vm: CockpitViewModel, modifier: Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        RateColumn("Laser", st.laserRate, 4, laserColor, Modifier.weight(1f)) { vm.cycleLaserRecharge() }
        if (hasShields)
            RateColumn("Shield", st.shieldRate, 4, ShieldYellow, Modifier.weight(1f)) { vm.cycleShieldRecharge() }
        RateColumn("Engine", engineBoxes(st.laserRate, st.shieldRate, hasShields, beam, st.beamRate),
            enginePool(hasShields, beam), EngineBlue, Modifier.weight(1f), enabled = false) { }
        if (beam)
            RateColumn("Beam", st.beamRate, 4, BeamPurple, Modifier.weight(1f)) { vm.cycleBeamRecharge() }
    }
}

@Composable
private fun RateColumn(label: String, filled: Int, total: Int, color: Color,
                       modifier: Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Column(
        modifier.tap(enabled) { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0 until total) {
                val isFilled = i >= (total - filled)   // fill from the bottom up
                Box(
                    Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(3.dp))
                        .background(if (isFilled) color else color.copy(alpha = 0.15f))
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/* --------------------------- FIRE MODE GRAPHIC ---------------------------
 * Craft-shaped cannon dots. Light-blue ring = a cannon; bright-green fill = a
 * firing laser; near-white-blue fill = a firing ion cannon. The number of lit
 * dots reflects the fire mode (single/dual/triple/quad); LAS+ION lights every
 * laser AND every ion together. Positions are normalized (0..1, x right/y down).
 * ------------------------------------------------------------------------- */
private val LaserGreenLit = GlowGreen                // Imperial lasers
private val LaserRedLit = Color(0xFFFF5A5A)          // Rebel lasers
private val IonLit = Color(0xFFD9F1FF)      // almost-white blue
private val CannonRing = Color(0xFF7FB8DE)  // light blue ring

private fun laserPositions(ship: Ship): List<Offset> = when {
    ship.laserCannons == 1 -> listOf(Offset(0.5f, 0.5f))                       // Missile Boat
    ship.id == "tie_defender" -> listOf(                                        // trapezoid
        Offset(0.20f, 0.46f), Offset(0.80f, 0.46f),                             //  top pair, wide
        Offset(0.38f, 0.78f), Offset(0.62f, 0.78f))                             //  bottom pair, close
    ship.id == "bwing" -> listOf(                                              // 3, inverted triangle
        Offset(0.33f, 0.42f), Offset(0.67f, 0.42f), Offset(0.5f, 0.80f))
    ship.laserCannons >= 4 -> listOf(                                           // square
        Offset(0.30f, 0.34f), Offset(0.70f, 0.34f),
        Offset(0.30f, 0.70f), Offset(0.70f, 0.70f))
    else -> listOf(Offset(0.34f, 0.5f), Offset(0.66f, 0.5f))                    // 2 side by side
}

// Which cannon indices light up for a given mode. On 4-cannon craft DUAL fires
// a diagonal cross (index 0 + 3), matching the games; otherwise it's the first N.
private fun litIndices(count: Int, label: String): Set<Int> = when (label) {
    "DUAL"   -> if (count >= 4) setOf(0, 3) else setOf(0, 1)
    "TRIPLE" -> setOf(0, 1, 2)
    "QUAD"   -> setOf(0, 1, 2, 3)
    else     -> setOf(0)   // SINGLE
}

// Returns (position, fillColor-or-null). null fill = unlit (ring only).
private fun fireDots(ship: Ship, weapon: String, fireLabel: String): List<Pair<Offset, Color?>> {
    val laserLit = if (ship.faction == Faction.REBEL) LaserRedLit else LaserGreenLit
    return when {
        weapon == "LASERS" && fireLabel == "LAS+ION" -> {
            val ionsTop = listOf(Offset(0.40f, 0.15f), Offset(0.60f, 0.15f))
            laserPositions(ship).map { it to laserLit as Color? } + ionsTop.map { it to IonLit as Color? }
        }
        weapon == "LASERS" -> {
            val las = laserPositions(ship); val lit = litIndices(las.size, fireLabel)
            las.mapIndexed { i, p -> p to (if (i in lit) laserLit else null) }
        }
        weapon == "IONS" -> {
            val lit = litIndices(2, fireLabel)
            listOf(Offset(0.35f, 0.5f), Offset(0.65f, 0.5f))
                .mapIndexed { i, p -> p to (if (i in lit) IonLit else null) }
        }
        else -> {   // warheads: two launchers, single/dual
            val lit = litIndices(2, fireLabel)
            listOf(Offset(0.35f, 0.5f), Offset(0.65f, 0.5f))
                .mapIndexed { i, p -> p to (if (i in lit) Amber else null) }
        }
    }
}

@Composable
private fun FireModeGraphic(ship: Ship, weapon: String, fireLabel: String, modifier: Modifier) {
    val dots = fireDots(ship, weapon, fireLabel)
    Canvas(modifier) {
        val d = size.minDimension
        val r = d * 0.10f
        val strokeW = (d * 0.033f).coerceAtLeast(3f)
        dots.forEach { (pos, fill) ->
            val c = Offset(pos.x * size.width, pos.y * size.height)
            if (fill != null) drawCircle(fill, r, c)
            drawCircle(CannonRing, r, c, style = Stroke(width = strokeW))
        }
    }
}

/* --------------------------- SHIP INDICATOR ------------------------------- */
@Composable
private fun ShipIndicator(art: String, hasShields: Boolean, shield: ShieldConfig,
                          onCycle: () -> Unit, modifier: Modifier) {
    val ctx = LocalContext.current
    val resId = remember(art) { ctx.resources.getIdentifier(art, "drawable", ctx.packageName) }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val reserve = 34.dp                                   // room for the label below (full descenders)
        val fit = if (maxWidth < maxHeight - reserve) maxWidth else maxHeight - reserve
        val dim = fit.coerceIn(90.dp, 280.dp)                 // bounded square, no overflow
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(dim)                            // tap area == the square only
                    .tap(hasShields) { onCycle() },
                contentAlignment = Alignment.Center
            ) {
                if (hasShields) ShieldRing(shield, Modifier.fillMaxSize())
                if (resId != 0) {
                    Image(painterResource(resId), contentDescription = null,
                        modifier = Modifier.fillMaxSize(0.6f), contentScale = ContentScale.Fit)
                } else {
                    Box(Modifier.fillMaxSize(0.42f).clip(RoundedCornerShape(10.dp))
                        .background(Panel), contentAlignment = Alignment.Center) {
                        HudLabel("no art", Dim, 11)
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            HudLabel(if (hasShields) "SHIELDS · ${shield.label}  (tap)" else "NO SHIELDS",
                if (hasShields) Green else Dim, 12)
        }
    }
}

@Composable
private fun ShieldRing(shield: ShieldConfig, modifier: Modifier) {
    Canvas(modifier) {
        val strokeW = size.minDimension * 0.045f
        val inset = strokeW / 2f + size.minDimension * 0.03f
        val d = size.minDimension - inset * 2f
        val topLeft = Offset((size.width - d) / 2f, (size.height - d) / 2f)
        val arcSize = Size(d, d)
        drawArc(Green.copy(alpha = 0.16f), 0f, 360f, false, topLeft, arcSize, style = Stroke(strokeW))
        val (start, sweep) = when (shield) {
            ShieldConfig.BALANCED -> 0f to 360f
            ShieldConfig.FORWARD -> 180f to 180f   // top half (front)
            ShieldConfig.REAR -> 0f to 180f        // bottom half (rear)
        }
        drawArc(Green, start, sweep, false, topLeft, arcSize, style = Stroke(strokeW, cap = StrokeCap.Round))
    }
}

/* ------------------------------ THROTTLE ---------------------------------- */
@Composable
private fun ThrottleColumn(current: ThrottleLevel, onSet: (ThrottleLevel) -> Unit, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        HudLabel("THROTTLE", GlowGreen, 12)
        val items = listOf(
            "FULL" to ThrottleLevel.FULL,
            "MATCH" to ThrottleLevel.MATCHED,
            "2/3" to ThrottleLevel.TWO_THIRDS,
            "1/3" to ThrottleLevel.ONE_THIRD,
            "ZERO" to ThrottleLevel.ZERO,
        )
        items.forEach { (label, lvl) ->
            ThrottleButton(label, current == lvl, Modifier.fillMaxWidth().weight(1f)) { onSet(lvl) }
        }
    }
}

@Composable
private fun ThrottleButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) GlowGreen.copy(alpha = 0.28f) else DarkRed)
            .then(if (selected) Modifier.border(2.dp, GlowGreen, RoundedCornerShape(6.dp)) else Modifier)
            .tap { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) GlowGreen else DarkRedText,
            fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

/* ------------------------------- CONFIG ----------------------------------- */
@Composable
fun ConfigScreen(vm: CockpitViewModel, onSwitchCraft: () -> Unit,
                 onDiagnostics: () -> Unit, onClose: () -> Unit) {
    val accent = accentFor(vm.ship?.faction)
    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel("CONFIG", accent, 16)
            Spacer(Modifier.weight(1f))
            HudButton("CLOSE", accent = Dim) { onClose() }
        }
        Spacer(Modifier.height(16.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("SWITCH CRAFT", accent = Amber, modifier = Modifier.fillMaxWidth()) { onSwitchCraft() }
            HudButton("RESET COCKPIT", accent = Amber, modifier = Modifier.fillMaxWidth()) { vm.reset(); onClose() }
            HudButton("DIAGNOSTICS", accent = Cyan, modifier = Modifier.fillMaxWidth()) { onDiagnostics() }
        }
    }
}

/* ------------------------------ COMMANDS ---------------------------------- */
@Composable
fun CommandsScreen(vm: CockpitViewModel, onClose: () -> Unit, onOpenGoals: () -> Unit) {
    val accent = accentFor(vm.ship?.faction)
    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel("SHIP COMMANDS", accent, 16)
            Spacer(Modifier.weight(1f))
            HudLabel("focus the game, then tap", Dim, 11)
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            COMMAND_GROUPS.forEach { group ->
                HudLabel(group.title, accent, 13)
                group.commands.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { c ->
                            val isGoals = c.label == "MISSION GOALS"
                            HudButton(c.label, accent = if (isGoals && vm.mission != null) Cyan else Amber,
                                fontSize = 12, singleLine = true,
                                modifier = Modifier.weight(1f)) {
                                vm.sendCommand(c)
                                if (isGoals && vm.mission != null) onOpenGoals()
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.height(8.dp))
        HudButton("CLOSE", accent = Dim, modifier = Modifier.fillMaxWidth()) { onClose() }
    }
}

/* ---------------------------- DIAGNOSTICS --------------------------------- */
@Composable
fun DiagnosticScreen(vm: CockpitViewModel, onBack: () -> Unit) {
    var status by remember { mutableStateOf(ShizukuInjector.status) }
    DisposableEffect(Unit) {
        val prev = ShizukuInjector.onStatusChange
        ShizukuInjector.onStatusChange = { status = it }
        onDispose { ShizukuInjector.onStatusChange = prev }
    }
    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel("INJECTION DIAGNOSTICS", Cyan, 16)
            Spacer(Modifier.weight(1f))
            HudButton("CLOSE", accent = Dim) { onBack() }
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
        val (msg, color) = when (status) {
            ShizukuInjector.Status.READY -> "READY — key link is live" to Green
            ShizukuInjector.Status.CONNECTING -> "Connecting to Shizuku service…" to Amber
            ShizukuInjector.Status.NO_PERMISSION -> "Shizuku permission not granted" to Amber
            ShizukuInjector.Status.NO_BINDER -> "Shizuku not running (start it first)" to Red
            ShizukuInjector.Status.UNKNOWN -> "Unknown" to Dim
        }
        HudLabel(msg, color, 13)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("GRANT / CONNECT", accent = Cyan, modifier = Modifier.weight(1f)) { ShizukuInjector.requestPermission() }
            HudButton("RETRY", accent = Dim, modifier = Modifier.weight(1f)) { ShizukuInjector.init() }
        }
        Spacer(Modifier.height(18.dp))
        HudLabel("PIPELINE CHECK", Cyan, 12)
        Spacer(Modifier.height(6.dp))
        HudLabel("This panel is intentionally non-focusable, so injected keys go " +
            "to whatever is focused on the MAIN screen — normally the game.", Dim, 12)
        Spacer(Modifier.height(6.dp))
        HudLabel("To verify: focus the game (or open any text field on the top " +
            "screen), then tap a test key below and watch it land there.", Dim, 12)
        Spacer(Modifier.height(14.dp))
        HudLabel("TEST KEYS", Dim, 12)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("S (shields)", accent = Green, modifier = Modifier.weight(1f)) { vm.testKey(android.view.KeyEvent.KEYCODE_S) }
                HudButton("W (weapon)", accent = Amber, modifier = Modifier.weight(1f)) { vm.testKey(android.view.KeyEvent.KEYCODE_W) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("F9 (laser)", accent = Red, modifier = Modifier.weight(1f)) { vm.testKey(android.view.KeyEvent.KEYCODE_F9) }
                HudButton("F10 (shield)", accent = Cyan, modifier = Modifier.weight(1f)) { vm.testKey(android.view.KeyEvent.KEYCODE_F10) }
            }
        }
        Spacer(Modifier.height(14.dp))
        HudLabel("ENERGY TRANSFER — which one moves energy in THIS game?", Dim, 12)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("Shift+F9  (S→L)", accent = Cyan, modifier = Modifier.weight(1f)) {
                    vm.testKey(android.view.KeyEvent.KEYCODE_F9, android.view.KeyEvent.KEYCODE_SHIFT_LEFT)
                }
                HudButton("Shift+F10  (L→S)", accent = Red, modifier = Modifier.weight(1f)) {
                    vm.testKey(android.view.KeyEvent.KEYCODE_F10, android.view.KeyEvent.KEYCODE_SHIFT_LEFT)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HudButton("'  (L→S alt)", accent = Cyan, modifier = Modifier.weight(1f)) {
                    vm.testKey(android.view.KeyEvent.KEYCODE_APOSTROPHE)
                }
                HudButton(";  (S→L alt)", accent = Red, modifier = Modifier.weight(1f)) {
                    vm.testKey(android.view.KeyEvent.KEYCODE_SEMICOLON)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        HudButton("BACK TO COCKPIT", accent = Dim, modifier = Modifier.fillMaxWidth()) { onBack() }
        Spacer(Modifier.height(8.dp))
        }
    }
}

/* ----------------------- MISSION SELECT + GOALS ------------------------- */

private val BodyText = Color(0xFFB9C6DA)

@Composable
fun MissionSelectScreen(
    game: Game, faction: Faction,
    onPick: (String?, Mission?) -> Unit, onBack: () -> Unit,
) {
    val accent = accentFor(faction)
    val context = LocalContext.current
    val battles = remember(game.id) { MissionRepository.battles(context, game.id) }
    var openBattle by remember { mutableStateOf<Battle?>(null) }
    val unit = if (game.id == GameId.XWING) "TOUR" else "BATTLE"

    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel(if (openBattle == null) "SELECT MISSION" else openBattle!!.name, accent, 16)
            Spacer(Modifier.weight(1f))
            HudLabel(game.id.display, Dim, 11)
        }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val b = openBattle
            if (b == null) {
                HudButton("NO $unit / CUSTOM MISSION", accent = Cyan,
                    modifier = Modifier.fillMaxWidth()) { onPick(null, null) }
                Spacer(Modifier.height(4.dp))
                HudLabel("${unit}S", accent, 13)
                battles.forEach { bat ->
                    HudButton(bat.name, accent = Amber, fontSize = 13,
                        modifier = Modifier.fillMaxWidth()) { openBattle = bat }
                }
            } else {
                var lastGroup = ""
                b.missions.forEach { m ->
                    if (m.group.isNotEmpty() && m.group != lastGroup) {
                        lastGroup = m.group
                        Spacer(Modifier.height(2.dp))
                        HudLabel(m.group.uppercase(), accent, 13)
                    }
                    val label = if (m.group.isNotEmpty() && m.name.startsWith(m.group))
                        m.name.removePrefix(m.group).trim() else m.name
                    HudButton(label, accent = Amber, fontSize = 12,
                        modifier = Modifier.fillMaxWidth()) { onPick(b.name, m) }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        HudButton("BACK", accent = Dim, modifier = Modifier.fillMaxWidth()) {
            if (openBattle != null) openBattle = null else onBack()
        }
    }
}

@Composable
private fun GoalBody(text: String, color: Color = BodyText, size: Int = 12) =
    Text(text, color = color, fontSize = size.sp, fontFamily = FontFamily.Monospace,
        lineHeight = (size + 5).sp)

@Composable
private fun GoalBullet(text: String, color: Color = BodyText) =
    Row(Modifier.fillMaxWidth().padding(top = 3.dp)) {
        Text("• ", color = color, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text(text, color = color, fontSize = 12.sp, fontFamily = FontFamily.Monospace, lineHeight = 17.sp)
    }

@Composable
private fun TieGoals(m: Mission, accent: Color) {
    if (m.desc.isNotBlank()) { Spacer(Modifier.height(6.dp)); GoalBody(m.desc) }
    Spacer(Modifier.height(12.dp))
    var diff by remember { mutableStateOf(0) } // 0=Hard 1=Medium 2=Easy
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("HARD", "MEDIUM", "EASY").forEachIndexed { i, lbl ->
            HudButton(lbl, active = diff == i, accent = accent, fontSize = 12, singleLine = true,
                modifier = Modifier.weight(1f)) { diff = i }
        }
    }
    Spacer(Modifier.height(12.dp))
    HudLabel("HIDDEN BONUS GOALS", Amber, 13)
    val gs = m.goals.filter { when (diff) { 0 -> it.h; 1 -> it.m; else -> it.e } }
    if (gs.isEmpty()) GoalBody("(no bonus goals at this difficulty)", Dim)
    else gs.forEach { GoalBullet(it.text, Amber) }
}

@Composable
private fun XwaGoals(m: Mission, accent: Color) {
    if (m.craft.isNotBlank()) { Spacer(Modifier.height(8.dp)); HudLabel("CRAFT", accent, 13); GoalBody(m.craft) }
    if (m.objectives.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("PRIMARY OBJECTIVES", accent, 13)
        m.objectives.forEach { GoalBullet(it) }
    }
    if (m.bonus.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("HIDDEN BONUS GOALS", Amber, 13)
        m.bonus.forEach { GoalBullet(it, Amber) }
    }
    if (m.opponents.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("OPPONENTS", accent, 13)
        m.opponents.forEach { GoalBullet(it) }
    }
    if (m.difficulties.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("DIFFICULTY", accent, 13)
        m.difficulties.forEach { GoalBullet(it) }
    }
    if (m.tips.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("TIPS", accent, 13)
        m.tips.forEach { GoalBullet(it) }
    }
    if (m.souvenir.isNotBlank()) {
        Spacer(Modifier.height(12.dp)); HudLabel("SOUVENIR", accent, 13); GoalBody(m.souvenir)
    }
}

@Composable
private fun XwingGoals(m: Mission, accent: Color) {
    if (m.craft.isNotBlank()) { Spacer(Modifier.height(6.dp)); HudLabel("CRAFT", accent, 13); GoalBody(m.craft) }
    if (m.desc.isNotBlank()) { Spacer(Modifier.height(12.dp)); HudLabel("MISSION", accent, 13); GoalBody(m.desc) }
    if (m.objectives.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("GOALS", Amber, 13)
        m.objectives.forEach { GoalBullet(it, Amber) }
    }
    if (m.tips.isNotEmpty()) {
        Spacer(Modifier.height(12.dp)); HudLabel("TIPS", accent, 13)
        m.tips.forEach { GoalBullet(it) }
    }
}

@Composable
fun GoalsScreen(vm: CockpitViewModel, onClose: () -> Unit) {
    val accent = accentFor(vm.ship?.faction)
    val m = vm.mission
    val gid = vm.game?.id
    HudScaffold {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HudLabel("MISSION GOALS", accent, 16)
            Spacer(Modifier.weight(1f))
            HudLabel(vm.missionBattle ?: "", Dim, 11)
        }
        Spacer(Modifier.height(10.dp))
        if (m == null) {
            HudLabel("No mission selected.", Dim, 13)
            Spacer(Modifier.weight(1f))
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 4.dp)) {
                Text(m.name, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace)
                when (gid) {
                    GameId.TIE -> TieGoals(m, accent)
                    GameId.XWING -> XwingGoals(m, accent)
                    else -> XwaGoals(m, accent)
                }
                Spacer(Modifier.height(4.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        HudButton("CLOSE", accent = Dim, modifier = Modifier.fillMaxWidth()) { onClose() }
    }
}
